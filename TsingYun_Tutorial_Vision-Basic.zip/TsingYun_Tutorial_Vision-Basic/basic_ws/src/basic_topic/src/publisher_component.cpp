#include "basic_topic/publisher_component.hpp"

using namespace std::chrono_literals;

namespace basic_topic
{

    PublisherComponent::PublisherComponent(const rclcpp::NodeOptions& options) :
        Node("publisher_node", options)
    {
            // 创建发布器
        publisher_ = this->create_publisher<geometry_msgs::msg::Quaternion>("quaternion_topic", 10);

    // 创建定时器，每500ms触发一次
        timer_ = this->create_wall_timer(500ms, std::bind(&PublisherComponent::timer_callback, this));

    // 初始化随机数生成器
        std::random_device rd;
        gen_ = std::mt19937(rd());
    }

    double PublisherComponent::normalize_angle(double angle)
    {
        angle = std::fmod(angle + kPi, 2.0 * kPi);
        if (angle < 0.0)
            angle += 2.0 * kPi;
        return angle - kPi;
    }

    geometry_msgs::msg::Quaternion PublisherComponent::rpy_to_quaternion(double roll, double pitch, double yaw)
    {
        geometry_msgs::msg::Quaternion q;
        const double cy = std::cos(yaw * 0.5);
        const double sy = std::sin(yaw * 0.5);
        const double cp = std::cos(pitch * 0.5);
        const double sp = std::sin(pitch * 0.5);
        const double cr = std::cos(roll * 0.5);
        const double sr = std::sin(roll * 0.5);

        q.w = cr * cp * cy + sr * sp * sy;
        q.x = sr * cp * cy - cr * sp * sy;
        q.y = cr * sp * cy + sr * cp * sy;
        q.z = cr * cp * sy - sr * sp * cy;
        return q;
    }

    void PublisherComponent::timer_callback()
    {
        // 生成随机 RPY
        std::uniform_real_distribution<double> dist(-kPi, kPi);
        double roll = dist(gen_);
        double pitch = dist(gen_);
        double yaw = dist(gen_);

        // 转换为四元数并发布
        auto msg = rpy_to_quaternion(roll, pitch, yaw);
        publisher_->publish(msg);

        // 打印发送的 RPY
        RCLCPP_INFO(this->get_logger(), "[Publisher] 发送: Roll=%.2f, Pitch=%.2f, Yaw=%.2f", roll, pitch, yaw);
    }

}  // namespace basic_topic

RCLCPP_COMPONENTS_REGISTER_NODE(basic_topic::PublisherComponent)
